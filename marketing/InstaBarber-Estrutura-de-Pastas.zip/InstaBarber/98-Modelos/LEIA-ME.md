# 98-Modelos

Modelos reutilizáveis. Copiar daqui, nunca editar o modelo.

- **Documentos**: Ata, proposta, contrato, relatório.
- **Mensagens**: E-mails e mensagens-tipo.
