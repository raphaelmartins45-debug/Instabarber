# Marca-e-Propriedade-Intelectual

Registo da marca InstaBarber e dos domínios, direitos de autor.
