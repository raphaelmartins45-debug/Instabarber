# 01-Juridico-e-Conformidade

Tudo o que protege o negócio: contratos, privacidade, marca, licenças.

- **Contratos-e-Termos**: Modelos de contrato, Anexo III, Termos e Condições.
- **Privacidade-e-RGPD**: Política de privacidade, registo de tratamentos, pedidos de titulares.
- **Marca-e-Propriedade-Intelectual**: Registo da marca InstaBarber e dos domínios, direitos de autor.
- **Licencas-e-Direitos-de-Imagem**: Licenças de fotografias e música, autorizações de imagem. Guardar o comprovativo de cada uma.
- **Pareceres-do-Jurista**: Revisões e respostas: desafio dos 90 dias, comparação de preços, «Feito em Portugal».
