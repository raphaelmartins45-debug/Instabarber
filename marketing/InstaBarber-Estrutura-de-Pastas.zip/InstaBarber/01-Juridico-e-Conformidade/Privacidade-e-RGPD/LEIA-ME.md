# Privacidade-e-RGPD

Política de privacidade, registo de tratamentos, pedidos de titulares.
