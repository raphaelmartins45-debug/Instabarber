# Pareceres-do-Jurista

Revisões e respostas: desafio dos 90 dias, comparação de preços, «Feito em Portugal».
