# Licencas-e-Direitos-de-Imagem

Licenças de fotografias e música, autorizações de imagem. Guardar o comprovativo de cada uma.
