# Barbearias

Uma subpasta por barbearia cliente (dados de contacto, configuração, histórico).
