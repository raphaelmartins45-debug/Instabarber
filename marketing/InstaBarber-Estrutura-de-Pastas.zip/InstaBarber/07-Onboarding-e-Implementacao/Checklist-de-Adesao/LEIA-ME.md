# Checklist-de-Adesao

Passos da adesão e documentos a recolher.
