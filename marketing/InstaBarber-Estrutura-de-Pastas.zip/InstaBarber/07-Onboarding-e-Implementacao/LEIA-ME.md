# 07-Onboarding-e-Implementacao

Pôr uma barbearia a funcionar no sistema.

- **Checklist-de-Adesao**: Passos da adesão e documentos a recolher.
- **Barbearias**: Uma subpasta por barbearia cliente (dados de contacto, configuração, histórico).
- **Formacao-e-Materiais**: Guias e vídeos de formação para donos e barbeiros.
- **Configuracao-Inicial**: Modelos de configuração: serviços, horários, página pública.
