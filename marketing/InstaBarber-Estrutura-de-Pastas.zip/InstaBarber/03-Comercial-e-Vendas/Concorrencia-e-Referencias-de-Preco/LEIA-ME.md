# Concorrencia-e-Referencias-de-Preco

Análise de mercado e fontes dos preços de referência (sem nomear concorrentes em público).
