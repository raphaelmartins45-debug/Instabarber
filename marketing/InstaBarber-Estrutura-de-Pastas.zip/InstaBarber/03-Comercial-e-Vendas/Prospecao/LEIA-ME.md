# Prospecao

Listas de barbearias, abordagens feitas, registo de contactos.
