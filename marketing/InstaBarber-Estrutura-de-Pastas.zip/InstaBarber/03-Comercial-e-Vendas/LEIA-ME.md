# 03-Comercial-e-Vendas

Do primeiro contacto à assinatura.

- **Prospecao**: Listas de barbearias, abordagens feitas, registo de contactos.
- **CRM-e-Leads**: Exportações do formulário do site e do CRM (dados pessoais: acesso restrito).
- **Propostas-e-Apresentacoes**: Propostas enviadas, apresentações comerciais.
- **Pilotos**: Barbearias piloto: acordos, condições de lançamento, acompanhamento.
- **Scripts-e-Objecoes**: Guiões de chamada e de mensagem, respostas às objeções mais comuns.
- **Concorrencia-e-Referencias-de-Preco**: Análise de mercado e fontes dos preços de referência (sem nomear concorrentes em público).
