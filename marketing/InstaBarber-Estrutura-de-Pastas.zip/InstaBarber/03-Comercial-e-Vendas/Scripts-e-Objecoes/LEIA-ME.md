# Scripts-e-Objecoes

Guiões de chamada e de mensagem, respostas às objeções mais comuns.
