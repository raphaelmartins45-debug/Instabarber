# Pilotos

Barbearias piloto: acordos, condições de lançamento, acompanhamento.
