# Outros-Paises

Roteiro de expansões (Parte P): Espanha, Brasil, outros países da UE.
