# 09-Expansao-e-Parcerias

Crescer para além do plano inicial. Dormente até haver ordem.

- **Outros-Paises**: Roteiro de expansões (Parte P): Espanha, Brasil, outros países da UE.
- **Parcerias**: Acordos com parceiros, revendedores e a empresa de TI familiar.
- **Candidaturas-e-Apoios**: Fundos, incentivos e candidaturas a programas.
