# Parcerias

Acordos com parceiros, revendedores e a empresa de TI familiar.
