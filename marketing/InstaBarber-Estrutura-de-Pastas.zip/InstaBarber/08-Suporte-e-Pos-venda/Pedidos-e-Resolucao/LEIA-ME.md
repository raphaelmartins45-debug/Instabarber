# Pedidos-e-Resolucao

Pedidos de apoio e como foram resolvidos.
