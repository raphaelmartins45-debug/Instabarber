# 08-Suporte-e-Pos-venda

Depois da venda: apoio, retenção e prova social.

- **Pedidos-e-Resolucao**: Pedidos de apoio e como foram resolvidos.
- **FAQ-e-Guias**: Perguntas frequentes e guias passo a passo.
- **Feedback-e-Testemunhos**: Opiniões e testemunhos, só com consentimento escrito.
- **Renovacoes-e-Cancelamentos**: Renovações, cancelamentos e motivos.
- **Manual-do-Operador**: Processos manuais da Performa LAB, passo a passo.
