# Fotos-e-Videos

Fotografias e vídeos reais, com autorização escrita.
