# 04-Marketing-e-Marca

Identidade, site e materiais. As redes sociais já têm pasta própria: ver o LEIA-ME.

- **Identidade-Visual**: Logótipos, cores, tipografia, regras de uso da marca.
- **Landing-e-Site**: Versões da landing e do site, textos aprovados.
- **Materiais-Impressos**: Flyer, cartão de visita, cartaz do QR code para a loja.
- **Textos-Aprovados**: Textos comerciais aprovados (frases, preços, comparações), para reutilizar sem reescrever.
- **Fotos-e-Videos**: Fotografias e vídeos reais, com autorização escrita.
- **Imprensa-e-Eventos**: Notícias, entrevistas, feiras e eventos.
