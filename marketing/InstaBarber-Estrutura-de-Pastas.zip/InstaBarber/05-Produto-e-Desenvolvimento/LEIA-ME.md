# 05-Produto-e-Desenvolvimento

O sistema em si: especificação, fases, ideias e qualidade. O código vive no repositório.

- **Especificacao**: Partes A a P do documento mestre.
- **Fases-de-Construcao**: Fases 0 a 9, com o resultado verificado de cada uma.
- **Design-e-Prototipos**: Ecrãs, protótipos e referências visuais.
- **Roadmap-e-Ideias**: Catálogo de atualizações (U-01 em diante) e ideias por avaliar.
- **Testes-e-Qualidade**: Relatórios de testes, auditorias, critérios de aceitação.
- **Repositorio**: Apontador para o repositório de código e regras de trabalho (CLAUDE.md).
