# Repositorio

Apontador para o repositório de código e regras de trabalho (CLAUDE.md).
