# Fases-de-Construcao

Fases 0 a 9, com o resultado verificado de cada uma.
