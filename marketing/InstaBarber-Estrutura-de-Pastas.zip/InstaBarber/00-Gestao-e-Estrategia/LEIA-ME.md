# 00-Gestao-e-Estrategia

Visão, plano e decisões do negócio. O que se decide e porquê.

- **Visao-e-Plano**: Plano de negócio, posicionamento, proposta de valor.
- **Metas-e-Indicadores**: Metas por trimestre e os números que as medem.
- **Reunioes-e-Atas**: Atas e pontos de decisão, com data.
- **Decisoes**: Espelho do DECISOES.md (D-01 em diante) e decisões fora do código.
