# Metas-e-Indicadores

Metas por trimestre e os números que as medem.
