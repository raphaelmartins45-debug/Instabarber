# Visao-e-Plano

Plano de negócio, posicionamento, proposta de valor.
