# Decisoes

Espelho do DECISOES.md (D-01 em diante) e decisões fora do código.
