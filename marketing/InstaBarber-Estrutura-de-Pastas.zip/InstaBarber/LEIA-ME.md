# InstaBarber · Pasta do projeto

Estrutura por sector do negócio. Criada a 21/10/2026.

## Como está organizado

| Pasta | Para quê |
| --- | --- |
| 00-Gestao-e-Estrategia | Visão, plano e decisões do negócio. O que se decide e porquê. |
| 01-Juridico-e-Conformidade | Tudo o que protege o negócio: contratos, privacidade, marca, licenças. |
| 02-Financas-e-Contabilidade | Dinheiro que entra e sai, impostos e preços. |
| 03-Comercial-e-Vendas | Do primeiro contacto à assinatura. |
| 04-Marketing-e-Marca | Identidade, site e materiais. As redes sociais já têm pasta própria: ver o LEIA-ME. |
| 05-Produto-e-Desenvolvimento | O sistema em si: especificação, fases, ideias e qualidade. O código vive no repositório. |
| 06-Tecnologia-e-Infraestrutura | Serviços onde o sistema corre. Nunca guardar palavras-passe nem chaves nesta pasta. |
| 07-Onboarding-e-Implementacao | Pôr uma barbearia a funcionar no sistema. |
| 08-Suporte-e-Pos-venda | Depois da venda: apoio, retenção e prova social. |
| 09-Expansao-e-Parcerias | Crescer para além do plano inicial. Dormente até haver ordem. |
| 10-Pessoas-e-Fornecedores | Quem trabalha connosco e a quem compramos. |
| 11-Dados-e-Metricas | O que os números dizem. |
| 98-Modelos | Modelos reutilizáveis. Copiar daqui, nunca editar o modelo. |
| 99-Arquivo | O que já não está em uso, por ano. Nada se apaga: arquiva-se. |

## Onde fica a gestão de redes sociais

Já a tens à parte. Recomendação: colocá-la dentro de `04-Marketing-e-Marca/` com o nome `Redes-Sociais`, para o marketing ficar todo junto. Se preferires, deixa-a fora e acrescenta uma pasta `12-Redes-Sociais`.

## Regras de nomes

- Pastas e ficheiros só em ASCII, sem acentos nem espaços (hífen em vez de espaço).
- Ficheiros: `AAAA-MM-DD-assunto-vN` (exemplo: `2026-10-21-proposta-barbearia-central-v2.pdf`).
- Uma versão final por documento. As anteriores vão para `99-Arquivo`.

## Regras de segurança

- Nunca guardar palavras-passe, chaves de API ou ficheiros `.env`. As chaves ficam só em `.env.local` do projeto, fora desta pasta.
- Dados pessoais de clientes e leads (RGPD) só em `03-Comercial-e-Vendas/CRM-e-Leads` e `07-Onboarding-e-Implementacao/Barbearias`, com acesso restrito.
- Fotografias e música: guardar a licença em `01-Juridico-e-Conformidade/Licencas-e-Direitos-de-Imagem`.

## Onde cai o que já existe

| Já existe | Vai para |
| --- | --- |
| Documento mestre e Partes A a P | `05-Produto-e-Desenvolvimento/Especificacao` |
| Fases 0 a 9 e PROGRESSO.md | `05-Produto-e-Desenvolvimento/Fases-de-Construcao` |
| DECISOES.md | `00-Gestao-e-Estrategia/Decisoes` (cópia; o original fica no repositório) |
| Catálogo de atualizações (U-01 a U-19) | `05-Produto-e-Desenvolvimento/Roadmap-e-Ideias` |
| Referências de preço | `03-Comercial-e-Vendas/Concorrencia-e-Referencias-de-Preco` |
| Logótipos e landing | `04-Marketing-e-Marca` |
| Manual do operador (Fase 9) | `08-Suporte-e-Pos-venda/Manual-do-Operador` |
| Parte P, roteiro de expansões | `09-Expansao-e-Parcerias/Outros-Paises` |
| Plano de Instagram | já tens a pasta de redes sociais |
