# Incidentes

Registo de falhas: o que aconteceu, impacto e como se resolveu.
