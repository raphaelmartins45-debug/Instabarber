# Custos-de-Infraestrutura

Custo mensal por serviço e quando muda de plano.
