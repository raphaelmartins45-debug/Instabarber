# Dominios-e-DNS

instabarber.pt e os defensivos (.es, .eu, .online): renovações e registos DNS.
