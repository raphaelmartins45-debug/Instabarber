# 06-Tecnologia-e-Infraestrutura

Serviços onde o sistema corre. Nunca guardar palavras-passe nem chaves nesta pasta.

- **Dominios-e-DNS**: instabarber.pt e os defensivos (.es, .eu, .online): renovações e registos DNS.
- **Contas-e-Servicos**: Lista dos serviços (Supabase, Vercel, Resend, e-mail) com titular e data de renovação. Sem credenciais.
- **Seguranca-e-Backups**: Política de cópias, testes de restauro, auditorias de segurança.
- **Custos-de-Infraestrutura**: Custo mensal por serviço e quando muda de plano.
- **Incidentes**: Registo de falhas: o que aconteceu, impacto e como se resolveu.
