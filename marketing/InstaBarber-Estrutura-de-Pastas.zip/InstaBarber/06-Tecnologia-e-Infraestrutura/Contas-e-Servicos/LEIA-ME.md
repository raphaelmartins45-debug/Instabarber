# Contas-e-Servicos

Lista dos serviços (Supabase, Vercel, Resend, e-mail) com titular e data de renovação. Sem credenciais.
