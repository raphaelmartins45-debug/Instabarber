# Equipa

Quem faz parte, funções e responsabilidades.
