# 10-Pessoas-e-Fornecedores

Quem trabalha connosco e a quem compramos.

- **Equipa**: Quem faz parte, funções e responsabilidades.
- **Freelancers-e-Prestadores**: Contratos e entregas de prestadores externos.
- **Fornecedores**: Fornecedores de serviços e materiais.
- **Formacao**: Formação da equipa.
