# 99-Arquivo

O que já não está em uso, por ano. Nada se apaga: arquiva-se.

