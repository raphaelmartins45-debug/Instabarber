# Despesas-e-Recibos

Faturas de fornecedores e despesas, por ano e mês.
