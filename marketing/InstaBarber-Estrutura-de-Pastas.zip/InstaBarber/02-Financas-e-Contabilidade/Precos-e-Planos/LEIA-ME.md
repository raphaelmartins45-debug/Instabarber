# Precos-e-Planos

Tabela de preços Basic e Pro, histórico de alterações.
