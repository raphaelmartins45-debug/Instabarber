# Faturacao

Faturas emitidas aos clientes, por ano e mês.
