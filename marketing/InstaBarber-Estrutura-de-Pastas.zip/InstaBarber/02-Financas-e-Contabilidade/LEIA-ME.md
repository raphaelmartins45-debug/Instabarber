# 02-Financas-e-Contabilidade

Dinheiro que entra e sai, impostos e preços.

- **Faturacao**: Faturas emitidas aos clientes, por ano e mês.
- **Despesas-e-Recibos**: Faturas de fornecedores e despesas, por ano e mês.
- **Impostos-e-IVA**: IVA (regime do art. 53.º do CIVA, a acompanhar), IRS/IRC, declarações.
- **Contabilista**: Troca de documentos e perguntas ao contabilista (expressão «IVA incluído», CAE).
- **Precos-e-Planos**: Tabela de preços Basic e Pro, histórico de alterações.
- **Orcamento-e-Previsoes**: Orçamento anual, fluxo de caixa, ponto de equilíbrio.
