# Impostos-e-IVA

IVA (regime do art. 53.º do CIVA, a acompanhar), IRS/IRC, declarações.
