# 11-Dados-e-Metricas

O que os números dizem.

- **Relatorios-Mensais**: Relatório do mês: clientes, receita, churn, leads.
- **Analises**: Análises pontuais (preço, funil, retenção).
- **Dashboards**: Exportações e links para painéis.
