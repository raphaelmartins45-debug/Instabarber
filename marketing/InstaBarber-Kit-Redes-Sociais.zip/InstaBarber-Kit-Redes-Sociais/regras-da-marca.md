## 9 · Marca

O nome InstaBarber refere-se ao instante. Não imitar nada do Instagram: nem
gradiente, nem câmara, nem tipografia. Escrever sempre «InstaBarber», com as
duas maiúsculas. Ver a nota da marca na Parte J.

---
## 11 · Redes sociais: o que não se diz

Nas publicações, legendas, bios e vídeos do Instagram **não se menciona a Performa LAB nem «feito em Viseu»**. A marca fala só como InstaBarber (decisão de 21/10/2026, D-67). A assinatura «InstaBarber · Performa LAB» do correio (secção 10) mantém-se.

Também **não aparece «piloto»** («vagas piloto», «barbearias piloto», palavra-chave PILOTO) em nenhuma publicação (D-68). O CTA das publicações é «Experimenta a demo» / «link na bio».
A promessa central nas publicações é «tudo o que a barbearia precisa, reunido num só sistema, sem pagar por cada serviço». Não usar «sem pagar por cada mensagem» como mensagem principal.

## 12 · Tom das legendas

As legendas e textos das publicações usam português falado de Portugal, com expressões e calão leve naturais («a sério que ainda…?», «bora», «fogo», «pá», «deixa-te de…», «é só…», «tás», «gajo» com moderação), como um barbeiro falaria com outro. Nada de tom de anúncio, de listas em tríade nem de frases que soem a texto gerado («feito para quem…», «pensado para…», «reunidos num só sistema»). Frases curtas, uma provocação ou pergunta por legenda. Exemplo do dono: «A sério que ainda usas lista no telemóvel para gerir a tua barbearia?» (D-69). Evitar brasileirismos (regra 4).

As legendas levam emojis com critério (2 a 5 por legenda, um no início da primeira linha e os restantes a separar ideias; nunca em fila). Pedido do dono, 21/10/2026.

O guia completo está em `marketing/instagram/GUIA-DE-VOZ-E-LINGUAGEM.md` (D-70).
